from django.db import models

class Company(models.Model):
    name = models.CharField(max_length=200)
    nit = models.CharField(max_length=30, unique=True)
    address = models.TextField(blank=True)
    timezone = models.CharField(max_length=50, default='America/Bogota')
    default_currency = models.CharField(max_length=3, default='COP')

class Party(models.Model):
    COMPANY_TYPE = [('client','Cliente'), ('supplier','Proveedor')]
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    party_type = models.CharField(max_length=10, choices=COMPANY_TYPE)
    nit = models.CharField(max_length=50, blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    phone = models.CharField(max_length=50, blank=True, null=True)

class Tax(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    rate = models.DecimalField(max_digits=9, decimal_places=4)
    code = models.CharField(max_length=50, blank=True)

class Product(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    name = models.CharField(max_length=255)
    sku = models.CharField(max_length=100, blank=True)
    price = models.DecimalField(max_digits=14, decimal_places=2)
    cost = models.DecimalField(max_digits=14, decimal_places=2, default=0)

class InventoryItem(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.DecimalField(max_digits=18, decimal_places=4, default=0)
    location = models.CharField(max_length=200, blank=True)

class Project(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    code = models.CharField(max_length=50)
    name = models.CharField(max_length=255)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
