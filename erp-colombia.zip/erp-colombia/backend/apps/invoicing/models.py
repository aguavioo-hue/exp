from django.db import models
from apps.accounting.models import Company, Party, Project, Tax

class Invoice(models.Model):
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    party = models.ForeignKey(Party, on_delete=models.PROTECT)
    number = models.CharField(max_length=100)
    issue_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    subtotal = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    tax_total = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    total = models.DecimalField(max_digits=18, decimal_places=2, default=0)
    project = models.ForeignKey(Project, on_delete=models.SET_NULL, null=True, blank=True)

class InvoiceLine(models.Model):
    invoice = models.ForeignKey(Invoice, related_name='lines', on_delete=models.CASCADE)
    product_name = models.CharField(max_length=255, blank=True)
    description = models.CharField(max_length=500, blank=True)
    quantity = models.DecimalField(max_digits=18, decimal_places=4)
    unit_price = models.DecimalField(max_digits=18, decimal_places=2)
    tax = models.ForeignKey(Tax, on_delete=models.SET_NULL, null=True, blank=True)
    line_total = models.DecimalField(max_digits=18, decimal_places=2)
