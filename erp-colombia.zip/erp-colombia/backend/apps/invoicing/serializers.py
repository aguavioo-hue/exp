from rest_framework import serializers
from apps.accounting.models import Tax
from .models import Invoice, InvoiceLine

class InvoiceLineSerializer(serializers.ModelSerializer):
    class Meta:
        model = InvoiceLine
        fields = ['id','product_name','description','quantity','unit_price','tax','line_total']

class InvoiceSerializer(serializers.ModelSerializer):
    lines = InvoiceLineSerializer(many=True)
    class Meta:
        model = Invoice
        fields = ['id','company','party','number','issue_date','due_date','subtotal','tax_total','total','lines','project']

    def create(self, validated_data):
        lines_data = validated_data.pop('lines')
        invoice = Invoice.objects.create(**validated_data)
        subtotal = 0
        tax_total = 0
        for l in lines_data:
            unit_price = l.get('unit_price', 0)
            quantity = l.get('quantity', 0)
            line_total = quantity * unit_price
            subtotal += line_total
            tax = l.get('tax', None)
            tax_amount = 0
            if tax:
                # tax may be an int (pk) or object; handle both
                if isinstance(tax, int):
                    tax_obj = Tax.objects.get(id=tax)
                else:
                    tax_obj = tax
                tax_amount = line_total * float(tax_obj.rate)
            tax_total += tax_amount
            InvoiceLine.objects.create(invoice=invoice, line_total=line_total, **l)
        invoice.subtotal = subtotal
        invoice.tax_total = tax_total
        invoice.total = subtotal + tax_total
        invoice.save()
        return invoice
