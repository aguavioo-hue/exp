import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { View, Text } from 'react-native';

function Placeholder({title}){return (<View style={{flex:1,alignItems:'center',justifyContent:'center'}}><Text>{title}</Text></View>)}

const Tab = createBottomTabNavigator();
export default function App(){
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Facturación" children={()=><Placeholder title="Facturación"/>} />
        <Tab.Screen name="Contabilidad" children={()=><Placeholder title="Contabilidad"/>} />
        <Tab.Screen name="Proyectos" children={()=><Placeholder title="Proyectos"/>} />
        <Tab.Screen name="Inventario" children={()=><Placeholder title="Inventario"/>} />
        <Tab.Screen name="Contactos" children={()=><Placeholder title="Contactos"/>} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
