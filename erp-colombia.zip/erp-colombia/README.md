# ERP-Colombia (inicio)
Repositorio inicial con backend Django + DRF y frontend Expo.

Pasos rápidos (desarrollo):
1. Copia el contenido en `backend/` y `frontend/`.
2. Levanta `docker-compose up --build` en `backend/`.
3. Crea migraciones: `docker-compose run web python manage.py migrate`.
4. Levanta frontend: en `frontend/` `npm install` y `npm run start`.
